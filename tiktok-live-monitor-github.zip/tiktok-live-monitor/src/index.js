import "dotenv/config";
import express from "express";
import { ACCOUNTS } from "./accounts.js";
import { checkAccounts } from "./tiktok-monitor.js";

const app = express();
const port = Number(process.env.PORT || 3000);
const configured = (process.env.TIKTOK_ACCOUNTS || "").split(",")
  .map(x => x.trim().replace(/^@/, "")).filter(Boolean);
const accounts = configured.length ? configured : ACCOUNTS;

let state = {
  updatedAt: null,
  accounts: accounts.map(username => ({
    username, live: false, url: `https://www.tiktok.com/@${username}/live`
  }))
};
let checking = false;

async function refresh() {
  if (checking) return;
  checking = true;
  try {
    const results = await checkAccounts(accounts);
    state = { updatedAt: new Date().toISOString(), accounts: results };
    console.log(state.accounts.map(a => `@${a.username}: ${a.live ? "LIVE" : "offline"}`).join(" | "));
  } finally { checking = false; }
}

app.get("/api/live", (_req, res) => {
  res.set("Cache-Control", "no-store");
  res.json(state);
});
app.get("/health", (_req, res) => res.json({ ok: true, updatedAt: state.updatedAt }));
app.use(express.static("public"));

app.listen(port, async () => {
  console.log(`TikTok monitor listening on http://localhost:${port}`);
  await refresh();
  setInterval(refresh, 60_000);
});
