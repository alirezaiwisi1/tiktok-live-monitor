import { TikTokLiveConnection } from "tiktok-live-connector";

const cache = new Map();

export async function checkAccount(username) {
  const clean = username.replace(/^@/, "").trim();
  try {
    const connection = new TikTokLiveConnection(clean);
    const live = await connection.fetchIsLive();
    const result = {
      username: clean,
      live: Boolean(live),
      url: `https://www.tiktok.com/@${clean}/live`,
      checkedAt: new Date().toISOString()
    };
    cache.set(clean, result);
    return result;
  } catch (error) {
    const previous = cache.get(clean);
    return {
      username: clean,
      live: previous?.live ?? false,
      url: `https://www.tiktok.com/@${clean}/live`,
      checkedAt: new Date().toISOString(),
      error: error instanceof Error ? error.message : String(error),
      stale: Boolean(previous)
    };
  }
}

export async function checkAccounts(usernames) {
  const results = [];
  for (const username of usernames) results.push(await checkAccount(username));
  return results;
}
