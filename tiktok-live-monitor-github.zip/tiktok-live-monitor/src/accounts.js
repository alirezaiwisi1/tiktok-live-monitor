export const ACCOUNTS = [
  "aropl.afganistan",
  "nasarhashem",
  "keyvan.alalmahdi",
  "user2277795158168",
  "mehr.ecp",
  "maryamalalmahdi",
  "aroplfarsi"
];
